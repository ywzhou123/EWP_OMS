#!/bin/bash

STATUS=$1


netstat -na |awk '/^tcp/{++S[$NF]} END{for(i in S)print i" "S[i]}'|grep $STATUS|awk '{print $2}'
